# Template of Multi-Patch made for old Cyberlink Products 2014 versions.

Source code of Template for VB.NET.
Made in .NET Framework 4.0

Multi-Patch screenshot: 
![reis_multiplatch](https://i.postimg.cc/fywQsfYH/img1.png)

Multi-Patch release link:
http://forum.ru-board.com/topic.cgi?forum=35&topic=52984