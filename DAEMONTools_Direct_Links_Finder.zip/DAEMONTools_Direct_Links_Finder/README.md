# DaemonTools Direct Offline Links Finder

Description: It is a small console program that obtains direct download links from the DaemonTools *Offline* installers.

Homepage: https://www.daemon-tools.cc/

Solution made in C# 7 with .NET Framework 4.7.2 under Visual Studio 2017.

Try the Finder online: https://dotnetfiddle.net/j8rhv9