﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("daemonTools Direct Links Finder")]
[assembly: AssemblyDescription("HTTP Links Finder")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ghost0507")]
[assembly: AssemblyProduct("daemonTools Direct Links Finder")]
[assembly: AssemblyCopyright("Copyright ©  2018 - Happy New Year 2019")]
[assembly: AssemblyTrademark("DTDLF")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("41e81e26-b934-4812-b784-7105d8796097")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
